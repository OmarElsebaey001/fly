for i in range(50):
	print("Hello World!<brc>Bye World!,900,600,20,{},white,black,10,sample_{}".format(i,i))
