from doctest import script_from_examples
from tkinter import Canvas
from script_helper import *
hex_color = "#FFFFFF"
im = create_full_image(900,600,20,b'Hello'.decode('utf-8'),'d.ttf','black',hex_color,5)
im.show()