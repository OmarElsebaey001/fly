from script_helper import * 
import sys 
import pandas as pd
input_file = sys.argv[1]
main_df = pd.read_csv(input_file)
fonts_df = pd.read_csv("fonts.csv")
for i in range(main_df.shape[0]):
    t       = main_df['text'][i]
    w       = main_df['width'][i]
    h       = main_df['height'][i]
    m       = main_df['margin'][i]
    f_index = main_df['font_index'][i]
    f = list(fonts_df.loc[fonts_df.font_index == f_index,'file'])[0]
    bc    = main_df['back_color'][i]
    fc    = main_df['front_color'][i]
    br    = main_df['border'][i]
    o     = main_df['output_name'][i] +'.png' 
    print("Processing:")
    print(w,h,m,t,f,fc,bc,br)
    image = create_full_image(w,h,m,t,f,fc,bc,br)
    image.save(o)
