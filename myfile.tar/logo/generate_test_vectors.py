f = open("fonts.csv", "r")

content = f.read()

content_list = content.splitlines()

f.close()


for i in range(len(content_list)-1):
    print(f"#$%^&*(()_Hello World!<brc>Bye World!,900,600,20,{i},white,black,10,sample_{i}")
