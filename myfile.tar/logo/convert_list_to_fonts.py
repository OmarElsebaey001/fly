import pandas as pd
df = pd.read_csv("mew")
df.to_csv("mew.csv")
#for i in range(86):
#    print(f"#$%^&*(()_Hello World!<brc>Bye World!,900,600,20,{i},white,black,10,sample_{i}")
