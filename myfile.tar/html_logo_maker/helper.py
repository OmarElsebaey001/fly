from html.parser import HTMLParser

class MyHTMLParser(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.all_texts = []
        self.temp_dict = {}
        self.st_tag = 0 
    
    def reset_data(self):
        self.all_texts = []
        print("Reseting : ", self.all_texts)
        self.temp_dict = {}
        self.st_tag = 0 
    
    def handle_starttag(self, tag, attrs):
        self.st_tag += 1 
        self.temp_dict = {"type" : tag , "attribute" : attrs }
        
    def handle_endtag(self, tag):
        self.st_tag -= 1
        self.all_texts.append(self.temp_dict)
        
    def handle_data(self, data):
        td = {"type" : "generic" , "Data" : data }
        if (self.st_tag == 0 ) :
            self.all_texts.append(td)
        else:
            self.temp_dict['Data'] = data

class logo_parser:
    def __init__(self,initial,color,font):
        self.raw = initial
        self.x   = self.raw
        self.color = color
        self.font  = font 
        self.line_stream =[]
        self.tokens = []
        self.create_line_stream()
        self.break_line_into_tokens()
        
    def extract_lines(self,all_texts):
        alist = []
        for i in all_texts : 
            aline={}
            aline['type']    = 'text'
            aline['color']   = "#"+self.color
            aline['bold']    = False
            aline['italic']  = False
            aline['value']    = i['Data']
            aline['font']    = self.font
            if(i['type'] == 't'):
                for atr in i['attribute'] : 
                    if (atr[0] == 'c'):
                        aline['color']  = atr[1]
                    elif(atr[0] == 'b'):
                        aline['bold']   = True
                    elif(atr[0] == 'i'):
                        aline['italic'] = True
            alist.append(aline)
        return alist

    def get_first_break_line(self):
        def_dict = ["<brl>","<brc>","<bra>"]
        br_lines = [self.x.index(value) if value in self.x else -1 for value in def_dict ]
        res_dict = dict(zip(def_dict, br_lines))
        res_dict = dict((k, v) for k, v in res_dict.items() if v >= 0)
        if (res_dict == {}) : 
            return "NONE",-1
        best_key = min(res_dict, key=res_dict.get)
        return best_key, res_dict[best_key]

    def extract_br_text(self,x,index):
        piece = x[:index] 
        return piece, x[index+5:]

    def register_line(self,aline,atype):
        self.line_stream.append((aline,atype))
        return 

    def create_line_stream(self):
        while (True) : 
            br_type,br_index = self.get_first_break_line()
            if (br_type == 'NONE') : 
                self.register_line(self.x,"TEXT")
                break 
            else:
                br_type,br_index = self.get_first_break_line()
                x_piece,self.x        = self.extract_br_text(self.x,br_index)
                self.register_line(x_piece,"TEXT")
                self.register_line(br_type,"BREAKLINE")
    def break_line_into_tokens(self) :
        for i in self.line_stream:
            if(i[1] == 'TEXT') :
                parser    = MyHTMLParser()
                parser.feed(i[0])
                raw_tokens       = parser.all_texts
                ct = self.extract_lines(raw_tokens)
                [self.tokens.append(j) for j in ct]
                #parser.reset_data()
            else:
                adata = i[0].replace("<","")
                adata = adata.replace(">","")
                self.tokens.append({"type":"breakline","value":adata})
        
