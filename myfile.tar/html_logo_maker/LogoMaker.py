import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
import logging
from helper import *
import pandas as pd 

class LogoMaker:

    def __init__(self, height, width, bg_color, margin, text_color, font, border, first_line_alignment, line_spacing):

        self.height = height
        self.width = width
        self.bg_color = bg_color
        self.margin = margin
        self.text_color = text_color
        self.font = font
        self.border = border
        self.first_line_alignment = first_line_alignment
        self.line_spacing = line_spacing

    def generate_html(self, tokens):

        style = """<style>
        #main {
          color: %s;
          background-color: %s;
          width: %spx;
          height: %spx;
          border: %spx solid black;
          text-align: %s;
          font-size: %spx;
          position: relative;
          font-family: '%s';
          padding: %s;
          }
        
        """ % (self.text_color, self.bg_color, self.width - self.margin, self.height - self.margin, self.border, self.first_line_alignment, self.width - self.margin, self.font, self.margin // 2)
        
        style += """#text {
        display: inline-block;
        position: absolute;
        top: 50%;
        left: 50%;
        -ms-transform: translate(-50%, -50%);
        transform: translate(-50%, -50%);
        white-space: nowrap;
        }
        """
        style += """br {
            display: block;
            margin: %spx;
            content: " ";

        }
        </style>
        """ % self.line_spacing
        
        line_num = 0
        div_content = '<div id="line%s" style="text-align: left; line-height: 0.7;">' % (line_num)
        breaklines = []
        for token in tokens:
            if token["type"] == "breakline":
                div_content += "</div><br>"
                line_num += 1
                div_content += '<div id="line%s" style="text-align: left; line-height: 0.7;">' % line_num
                breaklines.append(token["value"].lower())

            else:
                div_content += '<span style="font-family: \'%s\'; color: %s;' % (token['font'], token['color'])
                if token["italic"]:
                    div_content += " font-style: italic; "
                if token["bold"]:
                    div_content += " font-weight: bold; "
                
                div_content += '">' + token["value"] + " " + "</span>"
        div_content += "</div>"
        div = "<div id='main'><div id='text'>%s</div></div>" % div_content
        script = """<script>
        $( document ).ready(function() {
        resize_to_fit();
        });

        function resize_to_fit() {
            var fontsize = $('div#main div').css('font-size');
            $('div#main div').css('fontSize', parseFloat(fontsize) - 1);

            if ($('div#main div').height() >= $('div#main').height() || $('div#main div').outerWidth() >= $('div#main').width()) {
                adjust_alignment();
                resize_to_fit();
            }
        }

        function get_children_width(element_id) {
            var children = document.getElementById(element_id).children;
            var totalWidth = 0;

            for (var i = 0; i < children.length; i++) {
                totalWidth += parseInt(children[i].offsetWidth, 10);
            }
            return totalWidth;
        }

        function adjust_alignment() {
            var first_line_alignment = "%s";
            var breaklines = %s;
            var width_em = $("#text").width() / parseFloat($("#text").css("font-size"));

            var margin_left = 0;
            if (first_line_alignment === "center") {
                var children_width_em = get_children_width("line0")  / parseFloat($("#text").css("font-size")) / 2;
                center_em = width_em / 2;
                margin_left = center_em - children_width_em;
                $("#line0").css('marginLeft', margin_left.toString() + "em")
            }

            for (let i = 0; i < breaklines.length; i++) {
                if (breaklines[i] === "brl") {
                    $("#line" + (i+1).toString()).css('marginLeft', margin_left.toString() + "em");
                }
                else if (breaklines[i] === "brc") {
                    var children_width_em = get_children_width("line" + (i+1).toString())  / parseFloat($("#text").css("font-size")) / 2;
                    center_em = width_em / 2;
                    margin_left = center_em - children_width_em;
                    $("#line" + (i+1).toString()).css('marginLeft', margin_left.toString() + "em")
                }
            }

             
        }
        </script>""" % (self.first_line_alignment, str(breaklines))
        html = """<html><head><script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script></head><body>
        %s
        %s
        %s
        </body></html>""" % (div, style, script)
        with open("output.html", "w") as f:
            f.write(html)

    def generate_image(self, path="output.png"):

        if not os.path.isfile("output.html"):
            raise Exception("HTML file not generated. Please generate HTML file using generate_html method")

        options = Options()
        options.headless = True
        options.add_argument("--log-level=3")
        options.add_argument("--window-size=1920,1080")
        driver = webdriver.Chrome(options=options, service=Service(ChromeDriverManager(log_level=logging.ERROR).install()))
        file_url = "file://" + os.path.dirname(os.path.realpath(__file__)) + "/output.html"
        driver.get(file_url)
        element = driver.find_element(By.ID, "main")
        
        element.screenshot(path)
        driver.quit()
        

def generate_logo(text,w,h,bg_color,txt_color,margin,font,border,fl_align,line_spacing,out_file):
    logomaker = LogoMaker(height=h, width=w, bg_color=bg_color, text_color=txt_color, margin=margin, font=font, border=border, first_line_alignment=fl_align, line_spacing=line_spacing)
    lg_parser = logo_parser(text,txt_color,font)
    # lg_parser = logo_parser("<t c=0000FF>One</t><bra>Hello World","000000","Arial")
    tokens = lg_parser.tokens
    logomaker.generate_html(tokens)
    logomaker.generate_image(out_file)

df = pd.read_csv("in.csv")
from datetime import datetime
start = datetime.now()
for i in range(df.shape[0]):
    generate_logo(df['text'][i],df['w'][i],df['h'][i],df['bg_color'][i],df['txt_color'][i],df['margin'][i],df['font'][i],df['border'][i],df['fl_align'][i],df['line_spacing'][i],df['out_file'][i])
print(datetime.now()-start)